using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotRebuilder : MonoBehaviour
{
    static private int _rebuildStep = 1;
    [SerializeField]
    private List<GameObject> robotParts;
    [SerializeField]
    private ParticleSystem rebuildParticles;

    void Start()
    {
        UpdateRobot();
    }

    public void IncreaseRebuildStepCounter()
    {
        _rebuildStep++;
        rebuildParticles.Play();
        SoundManager.Instance.PlaySound("Audio/SFX/Others/ReconstructionAudio");
    }

    public void UpdateRobot()
    {
        for (int i = 0; i < _rebuildStep; i++)
            robotParts[i].SetActive(true);
    }
}
