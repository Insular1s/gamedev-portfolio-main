using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destination : MonoBehaviour
{
    RobotRebuilder robotRebuilder;
    private void Start()
    {
        robotRebuilder = GetComponent<RobotRebuilder>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("test");
        if (collision.CompareTag("Player"))
        { 
            collision.gameObject.SetActive(false);
            StartCoroutine(BuildAndSwitchLevel());
        }
    }

    IEnumerator BuildAndSwitchLevel()
    {
        robotRebuilder.IncreaseRebuildStepCounter();
        yield return new WaitForSeconds(1.0f);
        robotRebuilder.UpdateRobot();
        yield return new WaitForSeconds(1.5f);
        LevelManager.Instance.NextLevel();
    }
}
