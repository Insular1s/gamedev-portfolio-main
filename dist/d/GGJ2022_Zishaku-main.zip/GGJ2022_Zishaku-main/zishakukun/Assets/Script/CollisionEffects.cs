using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionEffects : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(collision.relativeVelocity.sqrMagnitude);
        if (collision.relativeVelocity.sqrMagnitude > 0.05)
            PlayCollisionSound(Mathf.Clamp01(collision.relativeVelocity.sqrMagnitude));
    }

    private void PlayCollisionSound(float volume)
    {
        SoundManager.Instance.PlaySound("Audio/SFX/Collisions/metal_collision_0" + Random.Range(1,10), volume);
    }

    private void PlayBigCollisionSound()
    {
        SoundManager.Instance.PlaySound("Audio/SFX/Collisions/446132__justinvoke__collision-3");
    }
}
