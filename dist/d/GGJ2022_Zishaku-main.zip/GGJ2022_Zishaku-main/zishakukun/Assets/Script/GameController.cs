using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private LevelManager _levelManager;
    private InputManager _inputManager;
    private Camera _camera;
    private MagnetRotation _currentRotatingMagnet;
    private List<GameObject> _spawnedObjects;
    private bool _levelStarted;

    void Awake()
    {
        _inputManager = InputManager.Instance;
        _levelManager = LevelManager.Instance;
        _camera = Camera.main;
        _spawnedObjects = new List<GameObject>();
        _levelStarted = false;
    }

    private void OnEnable()
    {
        _inputManager.OnStartTouch += HandleTouchStart;
        _inputManager.OnEndTouch += HandleTouchEnd;
        _inputManager.OnSpacebarPress += ResetCurrentLevel;
        if (_currentRotatingMagnet != null)
        {
            _inputManager.OnTouchHold += HandleObjectRotation;
        }
    }

    private void OnDisable()
    {
        _inputManager.OnStartTouch -= HandleTouchStart;
        _inputManager.OnEndTouch -= HandleTouchEnd;
        _inputManager.OnSpacebarPress -= ResetCurrentLevel;
        if (_currentRotatingMagnet != null)
        {
            _inputManager.OnTouchHold -= HandleObjectRotation;
        }
    }

    private void HandleTouchStart(Vector2 screenPosition)
    {
        var screenCoordinates = new Vector3(screenPosition.x, screenPosition.y, _camera.nearClipPlane);
        var worldCoordinates = _camera.ScreenToWorldPoint(screenCoordinates);

        RaycastHit2D hit = Physics2D.Raycast(worldCoordinates, Vector2.zero);
        if (hit)
        {
            Debug.Log(hit.collider.gameObject.name);
            if (hit.collider.CompareTag("RotationWidget"))
            {
                _currentRotatingMagnet = hit.collider.gameObject.GetComponentInParent<MagnetRotation>();
                _inputManager.OnTouchHold += HandleObjectRotation;
            }
            else if (hit.collider.CompareTag("Magnet"))
                hit.collider.gameObject.GetComponent<PullScript>().TogglePolarity();
        }
        else
        {
            var spawned = Spawn(screenPosition, _levelManager.NextItemToSpawn());
            if (spawned)
                SoundManager.Instance.PlaySound("Audio/SFX/Interactions/478196__jonnyruss01__click-2 1");
            else
                SoundManager.Instance.PlaySound("Audio/SFX/Interactions/478282__joao-janz__finger-tap-2-4 1");
        }
        
    }

    private void HandleTouchEnd(Vector2 screenPosition)
    {
        if (_currentRotatingMagnet != null)
        {
            _inputManager.OnTouchHold -= HandleObjectRotation;
            _currentRotatingMagnet = null;
        }
    }

    private void HandleObjectRotation(Vector2 position, Vector2 delta)
    {
        if (delta.sqrMagnitude > 0.1f)
        {
           _currentRotatingMagnet.Rotate(GetWorldCoordinates(position), GetWorldCoordinates(position-delta));
        }
    }

    public bool Spawn(Vector2 screenPosition, GameObject gameObject)
    {
        if (gameObject != null)
        {
            SoundManager.Instance.PlaySound("Audio/SFX/Interactions/478196__jonnyruss01__click-2 1");
            var newGO = Instantiate(gameObject, GetWorldCoordinates(screenPosition), Quaternion.identity);
            _spawnedObjects.Add(newGO);
            return true;
        }
        else
        {
            // Change this later
            StartCurrentLevel();
            return false;
        }
    }

    public void StartCurrentLevel()
    {
        if (!_levelStarted)
        {
            _levelStarted = true;
            var allMagnets = FindObjectsOfType<MonoBehaviour>().OfType<PullScript>();
            foreach (PullScript go in allMagnets)
            {
                go.gameObject.layer = 0;
            }
        }
        //foreach (GameObject go in _spawnedObjects)
        //{
        //    go.GetComponentInChildren<PullScript>().gameObject.layer = 0;
        //}
    }

    public void ResetCurrentLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        //if (_currentRotatingMagnet != null)
        //{
        //    _inputManager.OnTouchHold -= HandleObjectRotation;
        //}

        //foreach (GameObject go in _spawnedObjects)
        //    Destroy(gameObject);

        //_spawnedObjects.Clear();
        //_levelStarted = false;
    }

    private Vector3 GetWorldCoordinates(Vector2 screenPosition)
    {
        var screenCoordinates = new Vector3(screenPosition.x, screenPosition.y, _camera.nearClipPlane);
        return _camera.ScreenToWorldPoint(screenCoordinates);
    }
}
