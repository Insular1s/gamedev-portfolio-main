using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : Singleton<LevelManager>
{
    [System.Serializable]
    public struct GOArray
    {
        public List<GameObject> GameObjects;
    }

    public List<GOArray> MagnetListsByLevels;

    private int _currentLevel;
    private int _magnetPlacementCounter;

    private void Awake()
    {
        DontDestroyOnLoad(this);
        _currentLevel = 0;
        _magnetPlacementCounter = 0;
    }

    public void NextLevel()
    {
        _currentLevel++;
        if (_currentLevel == 3)
            SceneManager.LoadScene("Credits");
        else
        {
            _magnetPlacementCounter = 0;
            Debug.Log(_currentLevel);
            SceneManager.LoadScene("Level" + _currentLevel);
        }
    }

    public GameObject NextItemToSpawn()
    {
        if (MagnetListsByLevels[_currentLevel].GameObjects.Count > _magnetPlacementCounter)
        {
            return MagnetListsByLevels[_currentLevel].GameObjects[_magnetPlacementCounter++];
        }
        else
        {
            Debug.Log("Last magnet already placed");
            return null;
        }
    }

    public void ResetMagnetPlacement()
    {
        _magnetPlacementCounter = 0;
    }
}
