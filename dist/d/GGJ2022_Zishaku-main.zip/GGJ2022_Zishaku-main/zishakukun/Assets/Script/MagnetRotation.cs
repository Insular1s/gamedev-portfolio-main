using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagnetRotation : MonoBehaviour
{
    public void Rotate(Vector2 position, Vector2 delta)
    {
        //Debug.Log(Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg);
        //transform.Rotate(0, delta, 0);

       // var deltaAngle = Vector3.SignedAngle(position - (Vector2)transform.position, delta - (Vector2)transform.position, transform.position);

        transform.Rotate(0, 0, Mathf.Rad2Deg*CalcSignedCentralAngle(position - (Vector2)transform.position, delta - (Vector2)transform.position, -Vector3.forward));
    }

    //https://forum.unity.com/threads/is-vector3-signedangle-working-as-intended.694105/
    static public float CalcSignedCentralAngle(Vector3 dir1, Vector3 dir2, Vector3 normal)
        => Mathf.Atan2(Vector3.Dot(Vector3.Cross(dir1, dir2), normal), Vector3.Dot(dir1, dir2));
}
