using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

[DefaultExecutionOrder(-1)]
public class InputManager : Singleton<InputManager>
{
    // Delegates
    public delegate void StartTouchEvent(Vector2 position);
    public event StartTouchEvent OnStartTouch;

    public delegate void EndTouchEvent(Vector2 position);
    public event EndTouchEvent OnEndTouch;

    public delegate void TouchHoldEvent(Vector2 position, Vector2 delta);
    public event TouchHoldEvent OnTouchHold;

    public delegate void SpacebarEvent();
    public event SpacebarEvent OnSpacebarPress;

    // Touch Control Instance
    private TouchControls _touchControls;
    private bool _pressActive;
    private Vector2 _mainPressDelta;

    // Accessors
    public Vector2 MainPressDelta
    {
        get => _mainPressDelta;
    }

    // Actual functions
    private void Awake()
    {
        _touchControls = new TouchControls();
    }

    private void OnEnable()
    {
        _touchControls.Enable();
    }

    private void OnDisable()
    {
        _touchControls.Disable();
    }

    private void Start()
    {
        _touchControls.Touch.TouchPress.started += ctx => StartTouch(ctx);
        _touchControls.Touch.TouchPress.canceled += ctx => EndTouch(ctx);
        _touchControls.Spacebar.SpacebarPress.started += ctx => SpacebarPress(ctx);
    }

    private void StartTouch(InputAction.CallbackContext context)
    {
        if (OnStartTouch != null) OnStartTouch(_touchControls.Touch.TouchPosition.ReadValue<Vector2>());
    }

    private void EndTouch(InputAction.CallbackContext context)
    {
        if (OnEndTouch != null) OnEndTouch(_touchControls.Touch.TouchPosition.ReadValue<Vector2>());
    }

    private void SpacebarPress(InputAction.CallbackContext context)
    {
        Debug.Log("spacebar");
        if (OnSpacebarPress != null) OnSpacebarPress();
    }

    private void Update()
    {
        if (_touchControls.Touch.TouchPress.IsPressed())
        {
            _mainPressDelta = _touchControls.Touch.TouchHold.ReadValue<Vector2>();
            if(OnTouchHold != null)
                OnTouchHold(_touchControls.Touch.TouchPosition.ReadValue<Vector2>(), _mainPressDelta);
        }
    }
}
