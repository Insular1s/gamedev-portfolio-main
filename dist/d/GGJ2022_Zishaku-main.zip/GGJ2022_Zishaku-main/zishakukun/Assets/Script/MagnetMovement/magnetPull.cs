using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class magnetPull : MonoBehaviour
{
    public float m_Speed = 0.5f;
    public bool polarity = true;
    public bool isAttached = false;
    private GameObject magnet;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void FixedUpdate()
    {
        if (!polarity)
        {
            Destroy(gameObject.GetComponent<FixedJoint2D>());
            isAttached = false;
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector3(1, 1, 1) + m_Speed *
                       (transform.position - magnet.transform.position));
        }
        if (magnet)
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(m_Speed *
                       (magnet.transform.position - transform.position));

        }
        if (isAttached && !gameObject.GetComponent<FixedJoint2D>())
        {
            gameObject.AddComponent<FixedJoint2D>();
            gameObject.GetComponent<FixedJoint2D>()
            .connectedBody = magnet.GetComponent<Rigidbody2D>();
        }


    }

    private void OnTriggerEnter2D(Collider2D collider)
    {

        magnet = collider.gameObject;


        if (collider.CompareTag("MagnetCloseCollider"))
        {
            isAttached = true;
        }
        // if (collider.CompareTag("MagnetCloseCollider"))
        // {
        //     Debug.Log()
        // }








    }
}
