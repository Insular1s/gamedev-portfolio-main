using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class magAttach : MonoBehaviour

{
    public GameObject robot;
    public FixedJoint2D joint;
    public GameObject parentGameObject;

    private PullScript _parentPullScript;

    void Start()
    {
        parentGameObject = gameObject.transform.parent.gameObject;
        _parentPullScript = GetComponentInParent<PullScript>();
    }

    private void FixedUpdate()
    {
        if (robot && _parentPullScript.getPolarity() && !parentGameObject.GetComponent<FixedJoint2D>())
        {
            addJoint(robot, parentGameObject);

        }
        else if (robot && !_parentPullScript.getPolarity() && parentGameObject.GetComponent<FixedJoint2D>())
        {
            removeJoint(robot, parentGameObject);
        }
    }
    private void OnTriggerEnter2D(Collider2D collider)
    {
        
        if (collider.CompareTag("Player"))
        {
            robot = collider.gameObject;
            addJoint(robot, parentGameObject);
        }
    }

    private void addJoint(GameObject childObject, GameObject parentObject)
    {
        SoundManager.Instance.PlaySound("Audio/SFX/Collisions/411164__inspectorj__oidz-magnet-a-h1");
        parentObject.AddComponent<FixedJoint2D>();
        parentObject.GetComponent<FixedJoint2D>().connectedBody =
        childObject.GetComponent<Rigidbody2D>();
    }
    private void removeJoint(GameObject childObject, GameObject parentObject)
    {
        Destroy(parentObject.GetComponent<FixedJoint2D>());
        Destroy(childObject.GetComponent<FixedJoint2D>());

    }
}
