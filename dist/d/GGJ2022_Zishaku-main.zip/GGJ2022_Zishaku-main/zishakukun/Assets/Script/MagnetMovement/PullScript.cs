using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PullScript : MonoBehaviour
{
    public float m_Speed = 10f;

    public int m_TimerinSeconds = 3;

    public bool polarity = true;

    private GameObject robot;

    // Start is called before the first frame update

    IEnumerator TimerCoroutine()
    {
        for (int i = m_TimerinSeconds; i >= 0; i--)
        {
            yield return new WaitForSecondsRealtime(1);

        }

        Destroy(gameObject);
    }


    void Start()
    {
        if (gameObject.CompareTag("TimerMagnet"))
        {
            StartCoroutine(TimerCoroutine());

        }
    }

    // Update is called once per frame
    void Update()
    {

    }


    private void FixedUpdate()
    {
        if (robot)
        {
            Vector2 delta = gameObject.transform.position - robot.transform.position;

            if (polarity)
            {
                robot.GetComponent<Rigidbody2D>().AddForce(delta * m_Speed);
            }
            else
            {
                robot.GetComponent<Rigidbody2D>().AddForce(
                    ((-delta * m_Speed) / delta.magnitude));
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        collider.GetComponent<Rigidbody2D>().velocity = new Vector3(0, 0, 0);
        if (collider.CompareTag("Player"))
        {
            robot = collider.gameObject;
            Debug.Log("Player Hit ");

        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        // robot = null;
        if (!polarity)
        {
            robot = null;
        }
    }

    public void TogglePolarity()
    {
        SoundManager.Instance.PlaySound("Audio/SFX/Others/278204__ianstargem__switch-flip-2");
        Debug.Log("Toggled");
        polarity = !polarity;
    }

    public bool getPolarity()
    {
        return polarity;
    }

    public int getTimerInSeconds()
    {
        return m_TimerinSeconds;
    }

}

