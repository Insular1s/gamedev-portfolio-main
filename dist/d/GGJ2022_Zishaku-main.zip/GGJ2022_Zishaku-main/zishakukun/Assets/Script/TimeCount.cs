using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TimeCount : MonoBehaviour
{
    // Start is called before the first frame update
    private PullScript _parentPullScript; 
    private int m_timer;

    IEnumerator CountCoroutine()
    {
        for (int i = m_timer; i >= 0; i--)
        {
            yield return new WaitForSecondsRealtime(1);
            gameObject.GetComponent<TMPro.TextMeshPro>().text = $"{i}";

        }
    }
    void Start()
    {
        _parentPullScript = GetComponentInParent<PullScript>();
        m_timer = _parentPullScript.getTimerInSeconds();
        StartCoroutine(CountCoroutine());
    }

    // Update is called once per frame
    void Update()
    {

    }
}
