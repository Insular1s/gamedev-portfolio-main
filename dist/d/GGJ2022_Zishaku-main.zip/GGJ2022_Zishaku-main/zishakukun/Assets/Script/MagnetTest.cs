﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagnetTest : MonoBehaviour
{
    public float speedFactor;
    private GameObject robot;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        robot = collision.gameObject;
    }

    private void FixedUpdate()
    {
        if(robot)
            robot.GetComponent<Rigidbody2D>().AddForce(speedFactor*(transform.position - robot.transform.position));
    }
}
